<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.4" name="City" tilewidth="32" tileheight="32" tilecount="720" columns="60">
 <image source="ciudad.jpg" width="1920" height="384"/>
</tileset>
